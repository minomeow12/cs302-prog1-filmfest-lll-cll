//Evelyn Nguyen, CS302, prog1, 10/13/25
//Maincpp for Octoberfest

#include "menu.h"

int main() {
    Menu fest;
    fest.run();   
    return 0;
}

